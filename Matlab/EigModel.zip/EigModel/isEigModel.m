function is = isEigModel( m )

% return 1 iff m is an EigModel
