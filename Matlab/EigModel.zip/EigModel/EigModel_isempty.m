function b = EigModel_isempty( m )

b = isempty(m.org);

